-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2025 at 03:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `point of sale`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', '$2y$10$aicOmEH9cmk6qN.9MktiauagOm8fLoB8tjGnb2D5ZMORwOmKtAubG', '2025-10-09 13:31:09'),
(2, 'baba', '$2y$10$1wocQoICV4CEgmTbF3aB1euBPJTOd6ATZk1OtblUO69ybP7SkEH2a', '2025-10-17 13:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(10, 'balut'),
(1, 'Coffee'),
(6, 'Cookies&Breads'),
(5, 'Frappe (G)'),
(4, 'Frappe (S)'),
(11, 'kanin'),
(3, 'MilkTea (G)'),
(2, 'MilkTea (S)'),
(7, 'Promo'),
(12, 'prutas');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `category` varchar(100) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `name`, `price`, `stock`, `category`, `image_path`, `created_at`) VALUES
(32, 'kanin', 12.00, 0, 'kanin', 'uploads/almond.jpg', '2025-10-16 15:47:59'),
(34, 'jeff', 111.00, 0, 'Coffee', 'uploads/americano.webp', '2025-10-16 15:50:03'),
(35, 'we', 1.00, 0, 'kanin', '', '2025-10-16 15:51:06'),
(36, 'yess daddy', 112.00, 88, 'Cookies&Breads', 'uploads/americano.webp', '2025-10-16 15:51:24'),
(37, 'mamama', 123.00, 0, 'Frappe (S)', 'uploads/capuccinof.jpg', '2025-10-16 15:51:50'),
(38, 'pvs', 1231.00, 0, 'Coffee', 'uploads/caramelf.jpg', '2025-10-16 15:52:14'),
(39, 'kuko', 122.00, 0, 'Cookies&Breads', '', '2025-10-16 15:52:53'),
(40, 'Buy 1 Take 1 Coffee', 212.00, 0, 'Frappe (S)', 'uploads/chocobread.jpg', '2025-10-16 15:53:10'),
(41, 'Pandesal w/ Cheese', 12.00, 0, 'Cookies&Breads', 'uploads/garlic.jpg', '2025-10-16 15:53:27'),
(42, 'ramburat', 100.00, 0, 'prutas', 'uploads/almond.jpg', '2025-10-17 13:10:51');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `trans_no` varchar(50) NOT NULL,
  `user` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `trans_no`, `user`, `status`, `total_amount`, `created_at`, `completed_at`) VALUES
(1, 'ORD-20251009-162206-3621', 'admin', 'Completed', 140.00, '2025-10-09 22:22:08', '2025-10-09 22:22:08'),
(2, 'ORD-20251009-162403-1915', 'admin', 'Completed', 70.00, '2025-10-09 22:24:10', '2025-10-09 22:24:10'),
(3, 'ORD-20251015-180025-2213', 'admin', 'Completed', 123.00, '2025-10-16 00:00:32', '2025-10-16 00:00:32'),
(4, 'ORD-20251015-180330-6419', 'admin', 'Completed', 100.00, '2025-10-16 00:03:42', '2025-10-16 00:03:42'),
(5, 'ORD-20251015-180854-1603', 'admin', 'Completed', 861.00, '2025-10-16 00:25:34', '2025-10-16 00:25:34'),
(6, 'ORD-20251015-185138-3124', 'admin', 'Completed', 1230.00, '2025-10-16 00:51:44', '2025-10-16 00:51:44'),
(7, 'ORD-20251015-185632-3919', 'admin', 'Completed', 246.00, '2025-10-16 00:56:36', '2025-10-16 00:56:36'),
(8, 'ORD-20251015-190202-9209', 'admin', 'Completed', 246.00, '2025-10-16 01:02:59', '2025-10-16 01:02:59'),
(9, 'ORD-20251015-190916-1932', 'admin', 'Completed', 300.00, '2025-10-16 01:09:45', '2025-10-16 01:09:45'),
(10, 'ORD-20251015-190951-5032', 'admin', 'Completed', 100.00, '2025-10-16 01:15:08', '2025-10-16 01:15:08'),
(11, 'ORD-20251015-191017-8267', 'admin', 'Completed', 369.00, '2025-10-16 01:15:09', '2025-10-16 01:15:09'),
(12, 'ORD-20251015-191516-6634', 'admin', 'Completed', 223.00, '2025-10-16 01:15:42', '2025-10-16 01:15:42'),
(13, 'ORD-20251015-191704-8203', 'admin', 'Completed', 223.00, '2025-10-16 01:17:11', '2025-10-16 01:17:11'),
(14, 'ORD-20251016-150548-7700', 'admin', 'Completed', 100.00, '2025-10-16 21:09:29', '2025-10-16 21:09:29'),
(15, 'ORD-20251016-151244-6284', 'admin', 'Completed', 100.00, '2025-10-16 21:39:52', '2025-10-16 21:39:52'),
(16, 'ORD-20251017-151726-5714', 'admin', 'Completed', 224.00, '2025-10-17 21:18:58', '2025-10-17 21:18:58');

-- --------------------------------------------------------

--
-- Table structure for table `sales_history`
--

CREATE TABLE `sales_history` (
  `transaction_no` varchar(50) NOT NULL,
  `cashier` varchar(50) NOT NULL,
  `time` datetime DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'New'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_history`
--

INSERT INTO `sales_history` (`transaction_no`, `cashier`, `time`, `total`, `status`) VALUES
('ORD-20251009-162206-3621', 'admin', '2025-10-09 16:22:06', 140.00, 'New'),
('ORD-20251009-162403-1915', 'admin', '2025-10-09 16:24:03', 70.00, 'New'),
('ORD-20251015-180025-2213', 'admin', '2025-10-15 18:00:25', 123.00, 'Preparing'),
('ORD-20251015-180330-6419', 'admin', '2025-10-15 18:03:30', 100.00, 'Preparing'),
('ORD-20251015-180854-1603', 'admin', '2025-10-15 18:08:54', 861.00, 'New'),
('ORD-20251015-185138-3124', 'admin', '2025-10-15 18:51:38', 1230.00, 'Preparing'),
('ORD-20251015-185632-3919', 'admin', '2025-10-15 18:56:32', 246.00, 'New'),
('ORD-20251015-190202-9209', 'admin', '2025-10-15 19:02:02', 246.00, 'New'),
('ORD-20251015-190916-1932', 'admin', '2025-10-15 19:09:16', 300.00, 'New'),
('ORD-20251015-190951-5032', 'admin', '2025-10-15 19:09:51', 100.00, 'New'),
('ORD-20251015-191017-8267', 'admin', '2025-10-15 19:10:17', 369.00, 'New'),
('ORD-20251015-191516-6634', 'admin', '2025-10-15 19:15:16', 223.00, 'New'),
('ORD-20251015-191704-8203', 'admin', '2025-10-15 19:17:04', 223.00, 'New'),
('ORD-20251016-150548-7700', 'admin', '2025-10-16 15:05:48', 100.00, 'Preparing'),
('ORD-20251016-151244-6284', 'admin', '2025-10-16 15:12:44', 100.00, 'New'),
('ORD-20251017-151726-5714', 'admin', '2025-10-17 15:17:26', 224.00, 'New');

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(50) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_items`
--

INSERT INTO `sales_items` (`id`, `transaction_no`, `item_name`, `price`, `qty`) VALUES
(2, 'ORD-20251009-162206-3621', 'Black Coffee', 70.00, 2),
(3, 'ORD-20251009-162403-1915', 'Black Coffee', 70.00, 1),
(4, 'ORD-20251015-180025-2213', 'jeff', 123.00, 1),
(5, 'ORD-20251015-180330-6419', 'wemix', 100.00, 1),
(6, 'ORD-20251015-180854-1603', 'jeff', 123.00, 7),
(7, 'ORD-20251015-185138-3124', 'we', 123.00, 10),
(8, 'ORD-20251015-185632-3919', 'we', 123.00, 2),
(9, 'ORD-20251015-190202-9209', 'we', 123.00, 2),
(10, 'ORD-20251015-190916-1932', 'Buy 1 Take 1 Coffee', 100.00, 3),
(11, 'ORD-20251015-190951-5032', 'Buy 1 Take 1 Coffee', 100.00, 1),
(12, 'ORD-20251015-191017-8267', 'we', 123.00, 3),
(13, 'ORD-20251015-191704-8203', 'Buy 1 Take 1 Coffee', 100.00, 1),
(14, 'ORD-20251015-191704-8203', 'we', 123.00, 1),
(15, 'ORD-20251016-150548-7700', 'Buy 1 Take 1 Coffee', 100.00, 1),
(16, 'ORD-20251016-151244-6284', 'Buy 1 Take 1 Coffee', 100.00, 1),
(17, 'ORD-20251017-151726-5714', 'yess daddy', 112.00, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','cashier') DEFAULT 'cashier',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(2, 'bebe', '$2y$10$5/P0nQzmGVsOkRSOabeCRu0kjdwpdnvET5PlZ.9vUl4qzYKX8QkSa', 'cashier', '2025-09-16 05:41:01'),
(5, 'jeffrey', '$2y$10$Y6GNhPc1cYaThNR6iIkr1u4qTec8veWYb0fZtsXwJhIUeKkaqGbqS', 'cashier', '2025-09-16 05:48:46'),
(6, 'jason', '$2y$10$Xtg3k0QoGgXx5Yevkaq6iOkYlB1/fEeWvXqyjgw1Tj0vNgCwJa9hm', 'cashier', '2025-09-16 12:19:50'),
(7, 'NVJVJ@GMAIL.COM', '$2y$10$UChShXtrMJHphYQmzL6C9uDBwcnhoVYSU4mc3EiTmh452v/Izvh1i', 'cashier', '2025-09-16 21:06:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_history`
--
ALTER TABLE `sales_history`
  ADD PRIMARY KEY (`transaction_no`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_transaction` (`transaction_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `fk_transaction` FOREIGN KEY (`transaction_no`) REFERENCES `sales_history` (`transaction_no`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
